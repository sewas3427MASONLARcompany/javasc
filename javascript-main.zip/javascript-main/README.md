<h3>JavaScript</h3>
  JavaScript kodlarını Visual Studio Code, Sublime gibi editörlerde yazabilirsiniz <br>
  
  <a href="https://www.oguzhantas.com/javascript-egitimi/" target="_blank">Oguzhantas.com JavaScript kategorisine bakabilirsiniz</a>
